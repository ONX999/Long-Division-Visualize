# Long Division Visualizer

簡易直式除法步驟顯示器。前端純靜態網頁，直接部署到 GitHub Pages 即可使用。

## 使用方式
1. 輸入被除數與除數（正整數）。
2. 點擊「計算並顯示步驟」。
3. 顯示商、餘數、逐步過程與 ASCII 直式圖。

## GitHub Pages 部署
1. 建立新 repo，將此專案上傳。
2. 在 Settings > Pages 設定 Source 為 main branch / root。
3. 系統會產生公開網址。

## 延伸
可擴充支援小數、負數、步驟動畫化等功能。
